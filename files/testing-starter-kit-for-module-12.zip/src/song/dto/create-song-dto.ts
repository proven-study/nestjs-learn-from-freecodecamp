export interface CreateSongDTO {
  title: string;
}
