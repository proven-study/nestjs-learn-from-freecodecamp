export interface UpdateSongDTO {
  title?: string;
}
